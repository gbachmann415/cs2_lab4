/**
 * Gunnar Bachmann
 * CS2
 * 2/11/2020
 * Lab04
 */

package pokerGame;

import playingCards.Card;

import java.util.*;

/**
 * A human player for 2-card poker.
 * It depends on user input to decide whether to stand or fold.
 *
 * @author RIT CS
 * @author Gunnar Bachmann
 */
public class Human extends Player {

    //private PokerHand hand;

    /**
     * Initialize a human player for 2-card poker
	 * @param in the Scanner object to be used to prompt user for stand/fold
     */
    public Human( Scanner in ) {
		//this.hand = new PokerHand();
		super();
	}

    /**
     * Ask the player if they want to stand.
     * The player is prompted with a suitable message, and then
     * the players response from the Scanner is converted to
     * true (stand) or false (fold).
     *
     * @return true iff the human wants to stand
     */
    public boolean stand() {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter 'y' if you would like to stand, 'n' to fold");
		String response = scan.nextLine();
		if (response.equals("y")){
			return true;
		}
		else {
			return false;
		}
    }

	/**
	 * Get a string representing this human player
	 * @return all the information in {@link Player#toString()}, plus "Human"
	 */
	@Override
	public String toString() {
		return super.toString();
	}
}
