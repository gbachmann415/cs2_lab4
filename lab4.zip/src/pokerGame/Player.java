/**
 * Gunnar Bachmann
 * CS2
 * 2/11/2020
 * Lab04
 */

package pokerGame;

import playingCards.Card;
import java.util.*;

/**
 * An abstract Player for 2-card poker.
 *
 * @author RIT CS
 * @author Gunnar Bachmann
 */

public abstract class Player implements Comparable< Player > {

    protected PokerHand hand;
    private int playerPosition;
    private int playerWins;
    private static int incrPlayerPos = 0;

    /**
     * Initialize a player for 2-card poker.
     */
    public Player() {
        super();
        this.playerWins = 0;
        this.playerPosition = incrPlayerPos;
        incrPlayerPos += 1;
    }

    /**
     * Ask the player if they want to stand..
     *
     * @return a boolean value specifying if the human wants to stand
     */
    public abstract boolean stand();

    /**
     * Retrun the number of wins for this player.
     *
     * @return the number of wins
     */
    public int getWins() {
        return playerWins;
    }

    /**
     * Increment the number of wins for this player.
     */
    public void incrWins() {
        playerWins += 1;
    }

    /**
     * Add a card to the player's hand.
     *
     * @param c the card to add
     */
    public void addCard( Card c ) {
        this.hand.addCard(c);
    }

    /**
     * Print the hand in some "nice" format.
     */
    public void printHand() {
        System.out.println(this.hand.toString());
    }

    /**
     * Clear out all the player's cards.
     */
    public void newHand() {
        this.hand = new PokerHand();
    }

    /**
     * Get string representation of Player.
     * @return the part of the string representation common to all players:
     *         the player number
     */
    @Override
    public String toString() {
        return "Player #" + playerPosition;
    }

    /**
     * Compare this player's hand with the specified player's hand for order.
     * Returns <table BORDER="1">
     *     <caption>compareTo standard semantics</caption>
     * <tr><td>negative integer</td><td>player hand &lt; computers hand</td>
     * <tr><td>zero</td><td>player hand == computers hand</td>
     * <tr><td>positive integer</td><td>player hand &gt; computers hand</td>
     * </table>
     *
     * @return a negative integer, zero, or a positive integer as this
     *         player is less than, equal to, or greater than the other
     */
    @Override
    public int compareTo( Player other ) {
        return this.hand.compareTo(other.hand);
    }
}
