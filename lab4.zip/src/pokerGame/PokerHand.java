/**
 * Gunnar Bachmann
 * CS2
 * 2/11/2020
 * Lab04
 */

package pokerGame;

import playingCards.Card;
import playingCards.Rank;
import playingCards.Suit;

import java.util.*;

/**
 * A class to encapsulate a hand of cards for a 2-card poker game
 *
 * @author RIT CS
 * @author Gunnar Bachmann
 */
public class PokerHand implements Comparable< PokerHand > {

    private ArrayList<Card> hand;

    /**
     * Initialize a poker hand.
     * @rit.post The hand has no cards
     */
    public PokerHand() {
        this.hand = new ArrayList<Card>();
    }

    /**
     * Add a card to the hand.
     * This method must be called exactly twice because a hand size is 2.
     *
     * @param card the card to add to hand
     * @rit.post cards are in sorted order
     */
    public void addCard( Card card ) {
        hand.add(card);
    }

    /**
     * What kind of hand is this?
     *
     * @return one of the {@link HandType} designations
     * @rit.pre addCard has been called twice
     */
    HandType getType() {
        if (hand.get(0).getRank().equals(hand.get(1).getRank())) {
            return HandType.TWO_OF_KIND;
        }
        else if (hand.get(0).getSuit().equals(hand.get(1).getSuit())) {
            return HandType.FLUSH;
        }
        else {
            return HandType.REGULAR;
        }
    }

    /**
     * Show this hand's contents.
     *
     * @return a string containing all the cards in the hand
     */
    public String toString() {
        String card1 = this.hand.get(0).toString();
        String card2 = this.hand.get(1).toString();
        return "Your hand includes: " + card1 + ", " + card2;
    }

    /**
     * Finds which is the low card in the hand
     * @return low card
     */
    public Card lowestCard() {
       if (this.hand.get(0).getRank().getValue() > this.hand.get(1).getRank().getValue()) {
           return this.hand.get(1);
       }
       else {
           return this.hand.get(0);
       }
    }

    /**
     * Finds which is the high card in the hand
     * @return high card
     */
    public Card highestCard() {
        if (this.hand.get(0).getRank().getValue() > this.hand.get(1).getRank().getValue()) {
            return this.hand.get(0);
        }
        else {
            return this.hand.get(1);
        }
    }

    /**
     * Computes the hand value
     * @return integer value of the hand
     */
    public int handValue() {
        HandType type = this.getType();
        if (type == HandType.REGULAR) {
            return this.highestCard().value() * 14 + this.lowestCard().value();
        } else if (type == HandType.FLUSH) {
            return this.highestCard().value() * 14 + this.lowestCard().value() + 500;
        } else if (type == HandType.TWO_OF_KIND) {
            return this.highestCard().value() * 14 + this.lowestCard().value() + 1000;
        }
        return 0;
    }

    /**
     * Does this hand beat another hand?<br>
     * Rules
     * <ul>
     *     <li>
     *         Pair beats flush, which beats two arbitrary cards.
     *     </li>
     *     <li>
     *         Otherwise compare higher card ranks.
     *     </li>
     *     <li>
     *         If higher card ranks are the same, compare lower card ranks.
     *     </li>
     *     <li>
     *         If both card ranks are the same, return 0 -- hands are identical.
     *     </li>
     * </ul>
     */
    @Override
    public int compareTo( PokerHand other ) {
        return this.handValue() - other.handValue();
    }

}
